package com.tetratech.caddis.model;

public class SArrowLine extends Line {

}
