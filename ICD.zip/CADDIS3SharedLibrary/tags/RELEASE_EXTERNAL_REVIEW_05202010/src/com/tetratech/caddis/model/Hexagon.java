package com.tetratech.caddis.model;

public class Hexagon extends Shape {

}