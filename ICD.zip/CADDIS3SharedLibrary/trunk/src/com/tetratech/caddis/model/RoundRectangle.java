package com.tetratech.caddis.model;

public class RoundRectangle extends Shape {

}