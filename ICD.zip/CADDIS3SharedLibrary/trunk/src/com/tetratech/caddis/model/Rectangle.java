package com.tetratech.caddis.model;

public class Rectangle extends Shape {
		
}
