package com.tetratech.caddis.model;

public class Octagon extends Shape {

}