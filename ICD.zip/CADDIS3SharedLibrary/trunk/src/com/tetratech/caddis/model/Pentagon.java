package com.tetratech.caddis.model;

public class Pentagon extends Shape {

}