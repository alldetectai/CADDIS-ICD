select * from caddis_dev.P_CITATION where citation_id > 2455 and citation_id not in ( 2668, 2667, 2666, 2665, 2664, 2663)
