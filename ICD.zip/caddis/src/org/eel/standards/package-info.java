@javax.xml.bind.annotation.XmlSchema(namespace = "http://eel.org/standards")
package org.eel.standards;
