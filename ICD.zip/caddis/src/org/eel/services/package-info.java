@javax.xml.bind.annotation.XmlSchema(namespace = "http://eel.org/services")
package org.eel.services;
